package report.ygy;

import java.util.Comparator;

public abstract class Product implements Comparable<Product>{

	protected String model;
	protected String company;
	protected int date;
	protected int numOfStock;
	protected int price;
	protected int id=0;
	
	
	@Override
	public int compareTo(Product p) {
		return ((Integer)this.date).compareTo((Integer)(p.getDate()));
	}
	
	
	
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public int getDate() {
		return date;
	}
	public void setDate(int date) {
		this.date = date;
	}
	public int getNumOfStock() {
		return numOfStock;
	}
	public void setNumOfStock(int numOfStock) {
		this.numOfStock = numOfStock;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
		
}


//abstract class modelCompare implements Comparator<Product>{
//
//	public int compare(Product p1, Product p2) {	
//		return p1.getModel().compareTo(p2.getModel());
//	}	
//}
//
//abstract class modelReverseCompare implements Comparator<Product>{
//
//	public int compare(Product p1, Product p2) {	
//		return p2.getModel().compareTo(p1.getModel());
//	}
//}
//
//abstract class priceCompare implements Comparator<Product>{
//	public int compare(Product p1, Product p2) {
//		if(p1.getPrice()<p2.getPrice())	return -1;
//		else if(p1.getPrice()>p2.getPrice())	return 1;
//		else	return 0;
//	}
//}
//
//abstract class priceReverseCompare implements Comparator<Product>{
//	public int compare(Product p1, Product p2) {
//		if(p1.getPrice()>p2.getPrice())	return -1;
//		else if(p1.getPrice()<p2.getPrice())	return 1;
//		else	return 0;
//	}
//}